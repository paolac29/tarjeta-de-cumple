
document.getElementById("revealBtn").addEventListener("click", function() {
  const song = document.getElementById("birthdaySong");
  song.style.display = "block";
  song.play();
  alert("¡Te quiero mucho, Fer! 🌸💙");
});
